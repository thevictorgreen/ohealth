KeyLemon API PHP Library
http://www.keylemon.com

For documentation:
https://developers.keylemon.com

Release history:

July 2014 - Version 1.2.0
 * Added support for group of groups.

July 2014 - Version 1.1.0
 * Added support for age and gender.

June 2014 - Version 1.0.0
 * Stable release with age and gender support.

